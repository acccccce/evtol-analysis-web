@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "PYTHON_EXE="
if exist "E:\anaconda\python.exe" set "PYTHON_EXE=E:\anaconda\python.exe"
if not defined PYTHON_EXE (
    for /f "delims=" %%P in ('where python 2^>nul') do (
        if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
    )
)

if not defined PYTHON_EXE (
    echo [ERROR] Python was not found.
    pause
    exit /b 1
)

set "APP_PORT=8502"
set "APP_URL=http://localhost:%APP_PORT%"

echo Python: %PYTHON_EXE%
echo Starting eVTOL web deploy preview at %APP_URL%
echo If the browser opens 0.0.0.0, close that tab and use %APP_URL%
echo.

start "" "%APP_URL%"
"%PYTHON_EXE%" -m streamlit run "app.py" ^
  --server.port=%APP_PORT% ^
  --server.address=127.0.0.1 ^
  --server.headless=true ^
  --browser.serverAddress=localhost ^
  --browser.gatherUsageStats=false

pause
